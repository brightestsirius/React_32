import { createService } from "./createService";
const API = `https://6a05e129aa826ca75c0ac6a0.mockapi.io/users`;
const api = createService(API);

export const service = {
  login: async ({ email, password }) => {
    const users = await api.get();
    const user = users.find(
      (user) => user.email === email && user.password === password,
    );

    if (!user) {
      throw new Error("Invalid email or password");
    }

    return {
      user,
      accessToken: "mock-access-token",
    };
  },

  register: async ({ name, email, password }) => {
    const user = await api.post({ name, email, password });
    return { user, accessToken: "mock-access-token" };
  },
};
