import { create } from "zustand";
import { persist } from "zustand/middleware";

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      isAuth: false,
      login: (user, accessToken) => set({ user, accessToken, isAuth: true }),
      register: (user, accessToken) => set({ user, accessToken, isAuth: true }),
      logout: () => set({ user: null, accessToken: null, isAuth: false }),
    }),
    {
      name: "auth-storage",
    },
  ),
);
