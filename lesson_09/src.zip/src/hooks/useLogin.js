import { useMutation } from "@tanstack/react-query";
import { service } from "../api/authApi";
import { useAuthStore } from "./../store/authStore";

export function useLogin() {
  const login = useAuthStore((state) => state.login);

  return useMutation({
    mutationFn: (credentials) => service.login(credentials),
    onSuccess: (data) => {
      login(data.user, data.accessToken);
    },
  });
}
