import { useMutation } from "@tanstack/react-query";
import { service } from "../api/authApi";
import { useAuthStore } from "./../store/authStore";

export function useRegister() {
  const register = useAuthStore((state) => state.register);

  return useMutation({
    mutationFn: (credentials) => service.register(credentials),
    onSuccess: (data) => {
      register(data.user, data.accessToken);
    },
  });
}
