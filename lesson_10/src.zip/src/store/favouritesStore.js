import { create } from "zustand";
import { persist } from "zustand/middleware";

export const useFavouritesStore = create(
  persist(
    (set) => ({
      favouriteIds: [],
      setFavouriteId: (id) =>
        set((state) => ({ favouriteIds: [...state.favouriteIds, id] })),
    }),
    {
      name: "auth-storage",
    },
  ),
);